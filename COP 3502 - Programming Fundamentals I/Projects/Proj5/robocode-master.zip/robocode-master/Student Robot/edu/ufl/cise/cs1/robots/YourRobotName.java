package edu.ufl.cise.cs1.robots;

import robocode.TeamRobot;

public class YourRobotName extends TeamRobot
{

}
